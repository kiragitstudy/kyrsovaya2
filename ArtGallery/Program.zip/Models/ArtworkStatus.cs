namespace ArtGallery.Models
{
    public enum ArtworkStatus
    {
        InGallery,  // В галерее
        Sold,       // Продано
        Rented      // Сдано в аренду
    }
}