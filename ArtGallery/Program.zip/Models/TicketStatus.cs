namespace ArtGallery.Models
{
    public enum TicketStatus
    {
        Reserved,   // Зарезервировано
        Used,       // Использовано
        Cancelled   // Отменено
    }
}